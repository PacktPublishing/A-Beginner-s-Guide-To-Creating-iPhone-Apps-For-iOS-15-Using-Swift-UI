//
//  Design_PracticeApp.swift
//  Design Practice
//
//  Created by Nick Walter on 10/15/21.
//

import SwiftUI

@main
struct Design_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
