//
//  Emoji.swift
//  Emoji Dictionary
//
//  Created by Nick Walter on 10/18/21.
//

import Foundation


struct Emoji: Identifiable {
    var id: UUID
    var symbol: String
    var definition: String
    var rating: Int
}

var emojis: [Emoji] = [Emoji(id: UUID(), symbol: "😵‍💫", definition: "Spinny Face", rating: 2),
                       Emoji(id: UUID(), symbol: "⛪️", definition: "A Church, with beautiful glass I must say!", rating: 5),
                       Emoji(id: UUID(), symbol: "🤯", definition: "Mind Blown", rating: 4),
                       Emoji(id: UUID(), symbol: "😭", definition: "Tears Streaming", rating: 3),
                       Emoji(id: UUID(), symbol: "🤝", definition: "A handshake!", rating: 4),
                       Emoji(id: UUID(), symbol: "🦾", definition: "ROBOT ARM", rating: 3),
                       Emoji(id: UUID(), symbol: "🧙‍♂️", definition: "You're a wizard Harry!", rating: 5),
                       Emoji(id: UUID(), symbol: "🧶", definition: "Yarn", rating: 1),
                       Emoji(id: UUID(), symbol: "🎩", definition: "A Classy Tophat", rating: 2),
                       Emoji(id: UUID(), symbol: "🌝", definition: "A creepy looking moon", rating: 4),
                       Emoji(id: UUID(), symbol: "🌈", definition: "RAINBOW", rating: 4),
                       Emoji(id: UUID(), symbol: "🚕", definition: "Taxi...update this to an Uber!", rating: 3),
                       Emoji(id: UUID(), symbol: "🏪", definition: "コンビニです", rating: 5),
                       Emoji(id: UUID(), symbol: "🔮", definition: "A Crystal Ball", rating: 2),
                       Emoji(id: UUID(), symbol: "📈", definition: "STONKS ONLY GO UP", rating: 4),
                       Emoji(id: UUID(), symbol: "☢️", definition: "Hazard!", rating: 2),
                       Emoji(id: UUID(), symbol: "⌨️", definition: "Keyboard", rating: 2),
                       Emoji(id: UUID(), symbol: "👻", definition: "Ghost...BOOO!", rating: 4),
                       Emoji(id: UUID(), symbol: "🏎", definition: "One Cool Racecar", rating: 5)]
