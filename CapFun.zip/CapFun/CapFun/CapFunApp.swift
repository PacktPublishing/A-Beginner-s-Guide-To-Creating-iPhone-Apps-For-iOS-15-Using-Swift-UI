//
//  CapFunApp.swift
//  CapFun
//
//  Created by Nick Walter on 10/16/21.
//

import SwiftUI

@main
struct CapFunApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
