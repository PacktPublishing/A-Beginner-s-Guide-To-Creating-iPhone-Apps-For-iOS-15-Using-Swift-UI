
var age: Int? = 9

var name: String? = "Nick"

var isLightOn: Bool = true

var temp = "22"


var newTemp = Int(temp)

if newTemp != nil {
    newTemp! * 5
}

if let unwrappedTemp = newTemp {
    unwrappedTemp
}
