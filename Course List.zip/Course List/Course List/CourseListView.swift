//
//  ContentView.swift
//  Course List
//
//  Created by Nick Walter on 10/27/21.
//

import SwiftUI

struct CourseListView: View {
    
    @State var courses: [Course] = []
    
    var body: some View {
        if courses.count == 0 {
            VStack {
                ProgressView()
                    .padding()
                Text("Talking with the interwebs...")
                    .foregroundColor(.purple)
                    .onAppear(perform: {
                        getCourses()
                    })
            }
        } else {
            ScrollView {
                VStack(spacing:15) {
                    ForEach(courses) { listedCourse in
                        CourseTileView(course: listedCourse)
                    }
                }
            }
        }
    }
    
    func getCourses() {
        if let apiUrl = URL(string: "https://zappycode.com/api/courses?format=json") {
            
            var request = URLRequest(url: apiUrl)
            request.httpMethod = "GET"
            
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if error != nil {
                    print("There was an error")
                } else if data != nil {
                    // print(String(data: data!, encoding: .utf8) ?? "Error")
                    if let coursesFromAPI = try? JSONDecoder().decode([Course].self, from: data!) {
                        courses = coursesFromAPI
                    }
                }
            }.resume()
        }
    }
}

struct Course: Codable, Identifiable {
    var id: Int
    var title: String
    var subtitle: String
    var image: String
}

//struct TempImage_Previews: PreviewProvider {
//    static var previews: some View {
//        VStack {
//            Image(systemName: "books.vertical")
//                .font(.largeTitle)
//                .padding(80)
//        }
//        .frame(maxWidth: .infinity)
//        .background(Color.gray)
//    }
//}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        CourseListView()
    }
}
