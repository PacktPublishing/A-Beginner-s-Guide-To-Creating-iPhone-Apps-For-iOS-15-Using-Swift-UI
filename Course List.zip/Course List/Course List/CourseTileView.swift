//
//  CourseTileView.swift
//  Course List
//
//  Created by Nick Walter on 10/27/21.
//

import SwiftUI

struct CourseTileView: View {
    
    var course: Course
    
    var body: some View {
        ZStack {
            AsyncImage(url: URL(string: course.image)) { phase in
                switch phase {
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFill()
                default:
                    VStack {
                        Image(systemName: "books.vertical")
                            .font(.largeTitle)
                            .padding(80)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color.gray)
                }
            }
            VStack {
                Spacer()
                VStack {
                    HStack {
                        Text(course.title)
                            .bold()
                            .foregroundColor(.white)
                            .padding(5)
                        Spacer()
                    }
                    .background(Color.purple.opacity(0.8))
                }
            }
        }
    }
}

//VStack {
//    Spacer()
//    HStack {
//        VStack(alignment: .leading, spacing:0) {
//            Text(course.title)
//                .bold()
//                .foregroundColor(.white)
//                .padding(.horizontal, 5)
//                .padding(.top, 5)
//            Text(course.subtitle)
//                .foregroundColor(.white)
//                .padding(5)
//
//        }
//        Spacer()
//    }
//    .background(Color.purple.opacity(0.8))
//}

struct CourseTileView_Previews: PreviewProvider {
    static var previews: some View {
        CourseTileView(course: Course(id: 5, title: "Python in a Weekend: The Easiest Python for Beginners Course", subtitle: "HI THERE", image: "https://zappycode.com/media/course_images/3840036_f936.jpg"))
            .frame(height:200)
    }
}
