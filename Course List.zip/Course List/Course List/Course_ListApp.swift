//
//  Course_ListApp.swift
//  Course List
//
//  Created by Nick Walter on 10/27/21.
//

import SwiftUI

@main
struct Course_ListApp: App {
    var body: some Scene {
        WindowGroup {
            CourseListView()
        }
    }
}
