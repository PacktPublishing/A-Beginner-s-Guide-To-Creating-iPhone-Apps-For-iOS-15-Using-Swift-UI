//
//  ContentView.swift
//  No Save ToDos
//
//  Created by Nick Walter on 10/22/21.
//

import SwiftUI

struct ContentView: View {
    
    @State var toDos: [ToDo] = []
    @State var toDoText = ""
    
    var body: some View {
        VStack {
            TextField("Buy Cheese", text: $toDoText)
                .padding()
            
            Button(action: {
                let newToDo = ToDo(id: UUID(), text: toDoText)
                toDos.append(newToDo)
                toDoText = ""
            }) {
                Text("Add")
            }
            
            List(toDos) { listedToDo in
                Text(listedToDo.text)
            }
        }
    }
}

struct ToDo: Identifiable {
    var id: UUID
    var text: String
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
