//
//  No_Save_ToDosApp.swift
//  No Save ToDos
//
//  Created by Nick Walter on 10/22/21.
//

import SwiftUI

@main
struct No_Save_ToDosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
